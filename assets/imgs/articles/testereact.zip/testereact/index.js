
class Formulario extends React.Component{

constructor(props){
    super(props);
    this.state = {
        Name: '',
        Email: '',
    }

    this.handleSubmit = this.handleSubmit.bind(this);
    this.handleChange = this.handleChange.bind(this);

}

handleChange(event) {
    const { name, value } = event.target;
    this.setState({
      [name]: value,
    });
  }

  handleSubmit(event) {
    event.preventDefault();
    console.log("Formulário enviado com sucesso!");
  }


render(){

    return(React.createElement("form", {onSubmit: this.handleSubmit},
    React.createElement("label", null, "Name",
    React.createElement("input", {type: "text", value: this.state.Name, onChange: this.handleChange})),
    React.createElement("label", null, "Email",
    React.createElement("input", {type: "text", value: this.state.Email, onChange: this.handleChange})),
    React.createElement("input", {type: "submit", value: "Enviar"})));
    
}


}

ReactDOM.render(React.createElement(Formulario),document.getElementById('root'));